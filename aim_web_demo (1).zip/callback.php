
<?php
// callback.php - Giả lập webhook nhận tiền từ thueapi.pro

// Nhận dữ liệu JSON từ POST
$data = json_decode(file_get_contents("php://input"), true);

// Ghi log (chỉ demo)
file_put_contents("log.txt", json_encode($data, JSON_PRETTY_PRINT));

// Kiểm tra nội dung chuyển khoản
if (isset($data["description"]) && strpos($data["description"], "NAPTIEN_") !== false) {
    // Xử lý thành công đơn hàng tương ứng
    http_response_code(200);
    echo json_encode(["status" => "success", "message" => "Đã nhận thanh toán."]);
} else {
    http_response_code(400);
    echo json_encode(["status" => "error", "message" => "Mô tả không hợp lệ"]);
}
?>
